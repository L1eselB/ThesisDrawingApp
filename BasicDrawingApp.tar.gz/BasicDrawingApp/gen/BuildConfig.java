/** Automatically generated file. DO NOT MODIFY */
package com.example.liesel.basicdrawingapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
